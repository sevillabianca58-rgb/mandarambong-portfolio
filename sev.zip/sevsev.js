document.documentElement.classList.add('js');

/* ---------- EDIT YOUR CONTENT HERE ---------- */
var CONFIG = {
  email: 'sevillabianca58@gmail.com',
  facebook: 'https://www.facebook.com/share/1Sp9om5mPA/',
  instagram: 'https://www.instagram.com/bangky_pixie?srtk=MWZ5MjF5cThkMTBvbw==',
  github: '' /* paste your GitHub profile URL here, e.g. https://github.com/yourname */
};
var INFO = [
  ['Full name','Bianca A. Sevilla','user'],
  ['Nickname','Sevsev','smile'],
  ['Course and section','BSCS-2C','book'],
  ['Year level','Second Year','cal'],
  ['Team role','Designer','pen']
];
var ICONS = {
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.400 3.600-7 8-7s8 2.600 8 7"/>',
  smile:'<circle cx="12" cy="12" r="9"/><path d="M8 14c1 1.500 2.300 2.200 4 2.200s3-.7 4-2.200M9 9.500h.01M15 9.500h.01"/>',
  book:'<path d="M4 5c3-1 6-1 8 1 2-2 5-2 8-1v14c-3-1-6-1-8 1-2-2-5-2-8-1z"/><path d="M12 6v14"/>',
  cal:'<rect x="4" y="5" width="16" height="15" rx="3"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  pen:'<path d="M4 20l1-5L16 4l4 4L9 19z"/><path d="M14 6l4 4"/>',
  spark:'<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
  code:'<path d="M8 8l-5 4 5 4M16 8l5 4-5 4M14 5l-4 14"/>',
  tool:'<path d="M14 6a4 4 0 0 0 5 5l-9 9a2.800 2.800 0 0 1-4-4z"/><path d="M14 6l3-3 4 4-3 3"/>'
};
function ic(n){return '<span class="ico"><svg viewBox="0 0 24 24" aria-hidden="true">'+ICONS[n]+'</svg></span>'}
var SKILLS = [
  ['Design','pen',['Canva','Basic UI/UX Design','Wireframing','Layout and Color Selection','Basic Prototyping']],
  ['Programming','code',['Python','VB.NET','HTML','CSS','Basic JavaScript']],
  ['Tools','tool',['Visual Studio Code','Visual Studio','GitHub','Canva','Data Modeler']]
];
/* Set url to a live demo or repository to turn "Project Preview" into "View Project". Add tools:'...' once confirmed. */
var PROJECTS = [
  {n:'01',t:'Rental Tracking and Payment System',d:'A system designed to help organize rental information, monitor payment records, and keep track of rental transactions. The goal is to make rental management easier and more organized.',url:'',tools:'',cls:'s1',mock:'dash'},
  {n:'02',t:'Reverse Vending Machine System',d:'A project based on a reverse vending machine concept, where users can return recyclable containers through a system designed to support recycling and encourage responsible waste disposal.',url:'',tools:'',cls:'s2',mock:'rvm'},
  {n:'03',t:'Food Frenzy Game',d:'A burger-themed game project with both solo and two-player modes on the same screen. Players can enjoy a food-themed challenge while testing their timing, coordination, and gameplay skills.',url:'',tools:'',cls:'s3',mock:'game'},
  {n:'04',t:'Sari-Sari Store System',d:'A VB.NET project inspired by the neighborhood sari-sari store we all grew up with. We wanted to turn the way a small store runs every day into a program that feels easier and tidier than a notebook and pen.',url:'',tools:'VB.NET',cls:'s4',mock:'store'},
  {n:'05',t:'Class Fund System',d:'Our room handles a class fund together, so we are building a system to keep it clear and easy to follow for everyone. It is something we are working on right now, and it is still growing.',url:'',tools:'',cls:'s5',mock:'fund',status:'In progress'},
  {n:'06',t:'MANDARAMBONG',d:'Our team website, built together with my classmates. Every one of us gets our own portfolio inside it, so the site ends up being a mix of all our personalities. We are still building it right now.',url:'index.html',tools:'',cls:'s6',mock:'site',status:'In progress'}
];
/* ---------- /EDIT ---------- */

var BURGER='<svg viewBox="0 0 100 90" aria-hidden="true"><path d="M12 36C12 14 88 14 88 36z" fill="#E8A55B"/><circle cx="34" cy="26" r="2" fill="#fff3d6"/><circle cx="52" cy="22" r="2" fill="#fff3d6"/><circle cx="68" cy="27" r="2" fill="#fff3d6"/><path d="M10 38q8 8 16 0t16 0 16 0 16 0 16 0v6H10z" fill="#7CC27A"/><rect x="12" y="46" width="76" height="12" rx="6" fill="#6b3b2a"/><path d="M14 58h72l-8 10-10-6-10 6-10-6-10 6-10-6z" fill="#F6C945"/><path d="M12 70h76c0 10-8 14-18 14H30c-10 0-18-4-18-14z" fill="#E8A55B"/></svg>';
var MOCKS = {
 dash:'<div class="win reveal-img"><div class="bar"><i></i><i></i><i></i></div><div class="dash"><div class="side"><span class="a">Records</span><span>Payments</span><span>Units</span></div><div class="main"><div class="stats"><div><b>Units</b>Sample</div><div><b>Paid</b>Sample</div><div><b>Due</b>Sample</div></div><table class="tbl"><thead><tr><th>Unit</th><th>Due date</th><th>Status</th></tr></thead><tbody><tr><td>Unit A</td><td>Day 05</td><td><span class="pill paid">Paid</span></td></tr><tr><td>Unit B</td><td>Day 10</td><td><span class="pill pend">Pending</span></td></tr><tr><td>Unit C</td><td>Day 15</td><td><span class="pill paid">Paid</span></td></tr><tr><td>Unit D</td><td>Day 20</td><td><span class="pill over">Overdue</span></td></tr></tbody></table></div></div></div>',
 rvm:'<svg class="mock-svg reveal-img" viewBox="0 0 420 380" role="img" aria-label="Illustration of a reverse vending machine concept with bottles"><rect x="90" y="14" width="240" height="330" rx="34" fill="#30232B"/><rect x="108" y="32" width="204" height="134" rx="20" fill="#FFF9F3"/><circle cx="140" cy="62" r="11" fill="#7CC27A"/><path d="M135 62l4 4 7-8" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><text x="160" y="67" font-family="DM Sans,Arial" font-weight="700" font-size="15" fill="#30232B">Recycle here</text><text x="126" y="102" font-family="DM Sans,Arial" font-size="13" fill="#5b4753">Insert a container</text><rect x="126" y="116" width="168" height="34" rx="17" fill="#F8DDE9"/><text x="210" y="138" text-anchor="middle" font-family="DM Sans,Arial" font-weight="700" font-size="14" fill="#30232B">Containers: 3</text><rect x="128" y="186" width="164" height="54" rx="27" fill="#14090f"/><rect x="140" y="204" width="140" height="18" rx="9" fill="#3a2a33"/><rect x="108" y="262" width="204" height="62" rx="16" fill="#7CC27A"/><path d="M180 293a14 14 0 0 1 24-8m0 0v-9m0 9h-9M240 293a14 14 0 0 1-24 8m0 0v9m0-9h9" stroke="#fff" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/><g transform="rotate(-18 52 300)"><rect x="40" y="260" width="24" height="70" rx="9" fill="#EFA2C1"/><rect x="46" y="244" width="12" height="20" rx="4" fill="#EFA2C1"/><rect x="43" y="278" width="18" height="22" rx="3" fill="#fff9f3" opacity=".7"/></g><g transform="rotate(14 370 310)"><rect x="358" y="270" width="24" height="70" rx="9" fill="#B8A3E8"/><rect x="364" y="254" width="12" height="20" rx="4" fill="#B8A3E8"/><rect x="361" y="288" width="18" height="22" rx="3" fill="#fff9f3" opacity=".7"/></g><rect x="30" y="350" width="360" height="12" rx="6" fill="#30232B" opacity=".18"/></svg>',
 store:'<div class="win reveal-img"><div class="bar"><i></i><i></i><i></i><span class="wt">Sari-Sari Store</span></div><div class="store"><div class="items"><span>Biscuits</span><span>Candy</span><span>Soap</span><span>Noodles</span><span>Soda</span><span>Coffee</span></div><div class="order"><b>Order</b><p>Noodles <em>x2</em></p><p>Soda <em>x1</em></p><p>Candy <em>x5</em></p><div class="tot">Total</div></div></div></div>',
 fund:'<div class="win reveal-img"><div class="bar"><i></i><i></i><i></i><span class="wt">Class Fund</span></div><div class="fund"><svg class="ring" viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="48" fill="none" stroke="#F8DDE9" stroke-width="14"/><circle cx="60" cy="60" r="48" fill="none" stroke="#EFA2C1" stroke-width="14" stroke-linecap="round" stroke-dasharray="205 302" transform="rotate(-90 60 60)"/><text x="60" y="58" text-anchor="middle">Class</text><text x="60" y="76" text-anchor="middle">Fund</text></svg><table class="tbl"><thead><tr><th>Member</th><th>Status</th></tr></thead><tbody><tr><td>Member 1</td><td><span class="pill paid">Paid</span></td></tr><tr><td>Member 2</td><td><span class="pill pend">Pending</span></td></tr><tr><td>Member 3</td><td><span class="pill paid">Paid</span></td></tr></tbody></table></div></div>',
 site:'<div class="win reveal-img"><div class="bar"><i></i><i></i><i></i><span class="url">mandarambong</span></div><div class="site"><b class="logo2">MANDARAMBONG</b><div class="pgrid"><div class="pt me"><span class="av"></span>Sevsev</div><div class="pt"><span class="av"></span>Portfolio</div><div class="pt"><span class="av"></span>Portfolio</div><div class="pt"><span class="av"></span>Portfolio</div><div class="pt"><span class="av"></span>Portfolio</div><div class="pt"><span class="av"></span>Portfolio</div></div></div></div>',
 game:'<div class="game reveal-img"><div class="top"><span>Food Frenzy</span><div class="modes"><span>Solo</span><span class="a">2 Players</span></div></div><div class="screens"><div class="half">Player 1<span class="ord"> Order up!</span>'+BURGER+'</div><div class="half">Player 2<span class="ord"> Order up!</span>'+BURGER+'</div></div></div>'
};

/* opening animation: letters assemble, ink burst */
(function(){
  function build(el,txt,off){txt.split('').forEach(function(c,i){var s=document.createElement('span');s.className='ch';var a=Math.random()*6.283,d=150+Math.random()*260;s.style.setProperty('--x',Math.round(Math.cos(a)*d)+'px');s.style.setProperty('--y',Math.round(Math.sin(a)*d*.6)+'px');s.style.setProperty('--r',Math.round((Math.random()-.5)*320)+'deg');s.style.setProperty('--i',i+off);s.textContent=c;el.appendChild(s)})}
  build(document.getElementById('tt'),'Port',0);build(document.getElementById('tt2'),'folio',4);
  var b=document.getElementById('burst'),cols=['#30232B','#EFA2C1','#B8A3E8','#B77B96','#30232B'];
  for(var i=0;i<28;i++){var p=document.createElement('span'),a=Math.random()*6.283,d=80+Math.random()*300,dash=i%3===0,sz=dash?14:5+Math.random()*8;
    p.className='pc'+(dash?' dash':'');p.style.width=sz+'px';p.style.height=(dash?3.5:sz)+'px';p.style.background=cols[i%cols.length];
    p.style.setProperty('--dx',Math.round(Math.cos(a)*d)+'px');p.style.setProperty('--dy',Math.round(Math.sin(a)*d*.7)+'px');p.style.setProperty('--rot',Math.round(Math.random()*360)+'deg');
    p.style.animationDelay=(1.0+Math.random()*.12)+'s';b.appendChild(p)}
})();

/* info */
document.getElementById('infoGrid').innerHTML=INFO.map(function(r,i){return '<div class="tile rv" style="--rd:'+(i%3)*.08+'s">'+ic(r[2])+'<div><small>'+r[0]+'</small><b>'+r[1]+'</b></div></div>'}).join('');
/* skills */
document.getElementById('skillGrid').innerHTML=SKILLS.map(function(g,i){return '<div class="sk rv" style="--rd:'+i*.1+'s"><h3>'+ic(g[1])+g[0]+'</h3><ul class="badges">'+g[2].map(function(s){return '<li>'+s+'</li>'}).join('')+'</ul></div>'}).join('');
/* projects */
document.getElementById('plist').innerHTML=PROJECTS.map(function(p,i){
  var btn=p.url?'<a class="btn" href="'+p.url+'"'+(/^https?:/.test(p.url)?' target="_blank" rel="noopener"':'')+'>View Project</a>':'<button class="btn" type="button" data-p="'+i+'">Project Preview</button>';
  return '<article class="card rv"><div class="copy"><div class="ptop"><span class="pno">Project '+p.n+'</span>'+(p.status?'<span class="stat">'+p.status+'</span>':'')+'</div><h3>'+p.t+'</h3><p>'+p.d+'</p>'+(p.tools?'<p><b>Made with:</b> '+p.tools+'</p>':'')+btn+'</div><div class="shot '+p.cls+'">'+MOCKS[p.mock]+'</div></article>'}).join('');
/* socials */
var SV={fb:'<svg viewBox="0 0 24 24"><path d="M13.500 21v-8h2.700l.5-3.200h-3.200V7.900c0-.9.400-1.700 1.800-1.700h1.500V3.400S15.500 3.200 14.300 3.200c-2.600 0-4.200 1.500-4.200 4.300v2.300H7.300V13h2.800v8z"/></svg>',
ig:'<svg viewBox="0 0 24 24"><path d="M7.500 3h9A4.500 4.500 0 0 1 21 7.500v9a4.500 4.500 0 0 1-4.500 4.500h-9A4.500 4.500 0 0 1 3 16.500v-9A4.500 4.500 0 0 1 7.500 3zm0 1.800A2.700 2.700 0 0 0 4.800 7.500v9a2.700 2.700 0 0 0 2.700 2.700h9a2.700 2.700 0 0 0 2.700-2.700v-9a2.700 2.700 0 0 0-2.700-2.700zM12 7.500a4.500 4.500 0 1 1 0 9 4.500 4.500 0 0 1 0-9zm0 1.800a2.700 2.700 0 1 0 0 5.400 2.700 2.700 0 0 0 0-5.400zm4.800-2.900a1.100 1.100 0 1 1 0 2.200 1.100 1.100 0 0 1 0-2.200z"/></svg>',
gh:'<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 0 0-3.200 19.500c.5.100.7-.2.7-.5v-1.800c-2.800.6-3.400-1.200-3.400-1.200-.5-1.200-1.100-1.500-1.100-1.500-.9-.6.100-.6.100-.6 1 .1 1.600 1 1.600 1 .9 1.500 2.400 1.100 3 .8.100-.7.400-1.100.6-1.400-2.200-.3-4.600-1.100-4.600-5 0-1.100.4-2 1-2.700-.1-.3-.4-1.300.1-2.700 0 0 .8-.3 2.800 1a9.600 9.600 0 0 1 5 0c1.900-1.300 2.800-1 2.800-1 .5 1.400.2 2.400.1 2.700.6.700 1 1.600 1 2.700 0 3.900-2.400 4.700-4.600 5 .4.300.7.900.7 1.800v2.700c0 .3.200.6.700.5A10 10 0 0 0 12 2z"/></svg>',
ml:'<svg viewBox="0 0 24 24"><path d="M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1.500 2L12 12.200 18.500 7z"/></svg>'};
function soc(l,h,i){return '<a class="soc" href="'+h+'" target="_blank" rel="noopener" aria-label="'+l+' (opens in a new tab)">'+SV[i]+l+'</a>'}
var gh=CONFIG.github?soc('GitHub',CONFIG.github,'gh'):'<a class="soc" aria-disabled="true" role="link" tabindex="-1">'+SV.gh+'GitHub link coming soon</a>';
document.getElementById('socials').innerHTML='<a class="soc" href="mailto:'+CONFIG.email+'">'+SV.ml+'Email</a>'+soc('Facebook',CONFIG.facebook,'fb')+soc('Instagram',CONFIG.instagram,'ig')+gh;
if(!CONFIG.github)document.getElementById('ghNote').textContent='My GitHub profile will be linked here soon.';

/* copy email */
document.getElementById('copyMail').addEventListener('click',function(){
  var b=this,t=document.getElementById('mailText');
  function ok(){b.textContent='Copied';setTimeout(function(){b.textContent='Copy email'},1800)}
  function sel(){var r=document.createRange();r.selectNodeContents(t);var s=getSelection();s.removeAllRanges();s.addRange(r);b.textContent='Selected'}
  try{navigator.clipboard.writeText(CONFIG.email).then(ok,sel)}catch(e){sel()}
});

/* dialog */
var dlg=document.getElementById('dlg');
document.getElementById('plist').addEventListener('click',function(e){
  var b=e.target.closest('[data-p]');if(!b)return;var p=PROJECTS[b.dataset.p];
  document.getElementById('dlgT').textContent=p.t;document.getElementById('dlgP').textContent=p.d;
  document.getElementById('dlgN').textContent=p.status?'This project is still in progress, so there is no demo or repository to open yet. The mockup on the card is an interface concept.':'A live demo or repository for this project has not been added yet. The mockup on the card is an interface concept.';
  if(dlg.showModal)dlg.showModal();else dlg.setAttribute('open','');
});
document.getElementById('dlgX').addEventListener('click',function(){dlg.close?dlg.close():dlg.removeAttribute('open')});
dlg.addEventListener('click',function(e){if(e.target===dlg&&dlg.close)dlg.close()});

/* nav */
var burger=document.getElementById('burger'),links=document.getElementById('links');
burger.addEventListener('click',function(){var o=links.classList.toggle('open');burger.setAttribute('aria-expanded',o);burger.setAttribute('aria-label',o?'Close menu':'Open menu')});
links.addEventListener('click',function(e){if(e.target.closest('a')){links.classList.remove('open');burger.setAttribute('aria-expanded','false')}});
var navLinks=[].slice.call(document.querySelectorAll('.nav a.l'));
var secs=['home','about','skills','projects','achievements','contact'].map(function(i){return document.getElementById(i)});
var topBtn=document.getElementById('topBtn');
function onScroll(){
  var y=scrollY,cur=0;
  secs.forEach(function(s,i){if(s.getBoundingClientRect().top<innerHeight*.4)cur=i});
  navLinks.forEach(function(a,i){a.classList.toggle('on',i===cur)});
  topBtn.classList.toggle('show',y>700);
}
addEventListener('scroll',onScroll,{passive:true});onScroll();
topBtn.addEventListener('click',function(){scrollTo({top:0})});

/* reveal */
(function(){
  var els=[].slice.call(document.querySelectorAll('.rv,.card'));
  if(!('IntersectionObserver' in window)){els.forEach(function(e){e.classList.add('vis')});return}
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('vis');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
  els.forEach(function(e){io.observe(e)});
})();

/* gentle pointer parallax on floating objects (desktop only) */
if(matchMedia('(hover:hover)').matches&&!matchMedia('(prefers-reduced-motion:reduce)').matches){
  var ow=[].slice.call(document.querySelectorAll('.hero .obj-w')),raf;
  document.querySelector('.hero').addEventListener('mousemove',function(e){
    cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){
      var x=(e.clientX/innerWidth-.5),y=(e.clientY/innerHeight-.5);
      ow.forEach(function(o){var d=+o.dataset.depth;o.style.transform='translate('+x*d+'px,'+y*d+'px)'});
    });
  });
}

/* ===== PAGE BACKGROUND: position follows scroll progress (no timers) ===== */
(function(){
  var L=document.querySelector('.bg-scroll');if(!L)return;
  var im=L.firstElementChild,rm=matchMedia('(prefers-reduced-motion:reduce)'),max=0,tick=false;
  function measure(){max=Math.max(0,im.offsetHeight-L.offsetHeight);apply()}
  function apply(){
    tick=false;var d=document.documentElement.scrollHeight-innerHeight,
    p=rm.matches?.3:(d>0?Math.min(1,Math.max(0,scrollY/d)):0);
    im.style.transform='translate3d(-50%,'+(-p*max).toFixed(1)+'px,0)';
  }
  function req(){if(!tick){tick=true;requestAnimationFrame(apply)}}
  addEventListener('scroll',req,{passive:true});addEventListener('resize',measure);addEventListener('load',measure);
  if(im.complete)measure();else im.addEventListener('load',measure);
  if('ResizeObserver' in window)new ResizeObserver(req).observe(document.body);
})();
